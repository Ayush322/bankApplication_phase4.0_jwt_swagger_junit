package com.fis.bankApplicationMicroservices.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
//Define the primary key for the account
@Entity
public class Accounts {
	@Id
	
	@Min(value = 100, message = "Account ID Cannot be less than 100")
	@Max(value = 10000, message = "Account ID Cannot be more than 10000")
	private int acctID;
	private int balance;
	private String acctStatus;

	public Accounts() {

	}

	public Accounts(int acctID, int balance, String acctStatus) {
		super();
		// initialize account ID , balance and status
		this.acctID = acctID;
		this.balance = balance;
		this.acctStatus = acctStatus;
	}
// add getters and setters to this .
	public int getAcctID() {
		return acctID;
	}

	public void setAcctID(int acctID) {
		this.acctID = acctID;
	}

	public int getBalance() {
		return balance;
	}

	public void setBalance(int balance) {
		this.balance = balance;
	}

	public String getAcctStatus() {
		return acctStatus;
	}

	public void setAcctStatus(String acctStatus) {
		this.acctStatus = acctStatus;
	}

}
