package com.fis.bankApplicationMicroservices.repository;

import org.springframework.data.repository.CrudRepository;

import com.fis.bankApplicationMicroservices.model.BankCustomer;

public interface CustomerRepo extends CrudRepository<BankCustomer, Integer> {

}
