package com.fis.bankApplicationMicroservices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankAppJwtApplication {

	public static void main(String[] args) {
		// Run the spring application with BankAppJWT class and command line argument
		SpringApplication.run(BankAppJwtApplication.class, args);
	}

}
