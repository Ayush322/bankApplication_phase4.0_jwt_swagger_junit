package com.fis.bankApplicationMicroservices.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.NotBlank;
//{
//    "acctID": 1,
//    "transacType": "Deposited",
//    "transacStatus": "Success",
//    "initBal": 0,
//    "finalBal": 5000
//}
@Entity
public class Logger {

	@Id
	@NotBlank(message = "Account number cannot be null or whitespace")
	private int acctID;
	private String transacType;
	private String transacStatus;
	private int initBal;
	private int finalBal;

	public Logger() {

	}

	public Logger(int acctID, String transacType, String transacStatus, int initBal, int finalBal) {
		super();
		this.acctID = acctID;
		this.transacType = transacType;
		this.transacStatus = transacStatus;
		this.initBal = initBal;
		this.finalBal = finalBal;
	}

	public int getAcctID() {
		return acctID;
	}

	public void setAcctID(int acctID) {
		this.acctID = acctID;
	}

	public String getTransacType() {
		return transacType;
	}

	public void setTransacType(String transacType) {
		this.transacType = transacType;
	}

	public String getTransacStatus() {
		return transacStatus;
	}

	public void setTransacStatus(String transacStatus) {
		this.transacStatus = transacStatus;
	}

	public int getInitBal() {
		return initBal;
	}

	public void setInitBal(int initBal) {
		this.initBal = initBal;
	}

	public int getFinalBal() {
		return finalBal;
	}

	public void setFinalBal(int finalBal) {
		this.finalBal = finalBal;
	}

	public void error(String string) {
		// TODO Auto-generated method stub
		
	}

}
