package com.fis.bankApplicationMicroservices.config;

import java.io.IOException;
import java.io.Serializable;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.stereotype.Component;

//class responsible for handling authentication entry point for JWT.
@Component
public class JwtAuthenticationEntryPoint implements AuthenticationEntryPoint, Serializable {
   
	// Generated serialVersionID for serialization
	private static final long serialVersionUID = -7858869558953243875L;

	// override method for authenticationEntryPoint
	@Override
	public void commence(HttpServletRequest request, HttpServletResponse response,
			AuthenticationException authException) throws IOException {
      // send an unauthorized response with an error message
		response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Unauthorized");
	}
}