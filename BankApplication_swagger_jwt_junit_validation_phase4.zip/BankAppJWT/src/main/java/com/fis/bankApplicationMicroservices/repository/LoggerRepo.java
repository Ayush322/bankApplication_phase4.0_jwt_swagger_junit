package com.fis.bankApplicationMicroservices.repository;

import org.springframework.data.repository.CrudRepository;

import com.fis.bankApplicationMicroservices.model.Logger;

public interface LoggerRepo extends CrudRepository<Logger, Integer> {

}
